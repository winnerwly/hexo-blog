这是我的hexo的源码,欢迎提提意见

```bash
hexo g # 生成静态资源文件
```

```bash
hexo s # 运行本地环境
```

```bash
hexo d # 上传到github 使用此命令前需要先生成静态资源文件
```

```bash
hexo clean # 清楚当前生成的静态资源文件
```

[更多hexo命令](https://blog.csdn.net/qq_26975307/article/details/62447489)